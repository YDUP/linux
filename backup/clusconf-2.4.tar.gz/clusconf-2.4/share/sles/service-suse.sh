uncommentfile()
(
awk '$1 !~ /^#/ ' $1 |grep -v "127.0.0.1" |grep -v "::1" |grep -v "^$"
exit 0
)


#/sbin/chkconfig --level 35 nfsserver on

echo "turn off SuSEfirewall";sleep 1
/sbin/chkconfig --level 35 SuSEfirewall2_init  off
/sbin/chkconfig --level 35 SuSEfirewall2_setup off

if ! cat /etc/vimrc|grep backspace >>/dev/null;then
echo 'set backspace=indent,eol,start' >> /etc/vimrc
fi

if ! cat /etc/sysctl.conf |grep  vm.overcommit_memory >>/dev/null;then
cat >> /etc/sysctl.conf << EOF
# Stop nodes OOM'ing
vm.overcommit_memory = 2
vm.overcommit_ratio = 96
EOF
fi
echo "modifying  file: /etc/security/limits.conf...";sleep 1
if ! uncommentfile /etc/security/limits.conf |grep memlock >>/dev/null;then
cat >> /etc/security/limits.conf  << EOF
*    soft    memlock    unlimited
*    hard   memlock    unlimited
EOF
fi
if ! uncommentfile /etc/security/limits.conf |grep stack >>/dev/null;then
cat >> /etc/security/limits.conf  << EOF
*    soft    stack    unlimited
*    hard    stack    unlimited
EOF
fi

if ! uncommentfile /etc/sysconfig/pbs_mom  2>&1 |grep unlimited >> /dev/null;then
cat <<EOF >/etc/sysconfig/pbs_mom
ulimit -s unlimited
ulimit -l unlimited
EOF
fi

if ! [ -d /tmp/scratch ];then
mkdir /tmp/scratch
chmod 777 /tmp/scratch
fi
if ! uncommentfile /etc/crontab |grep tmpwatch >>/dev/null;then
cat >> /etc/crontab << EOF
0  0  *  *  *  root tmpwatch -umc 60d /tmp/scratch
EOF
fi

/sbin/chkconfig --level 35 cron on 2>&1 | grep -v insserv
/etc/init.d/cron restart
