
uncommentfile()
(
awk '$1 !~ /^#/ ' $1 |grep -v "127.0.0.1" |grep -v "::1" |grep -v "^$"
exit 0
)

#/sbin/chkconfig --level 35 nfs   on

echo "turn off iptables ip6tables sendmail service";sleep 1
/sbin/chkconfig --level 35 iptables off
/sbin/chkconfig --level 35 ip6tables off
/sbin/chkconfig --level 35 sendmail off 2>&1 | grep -v such
/sbin/chkconfig --level 35 NetworkManager off
/etc/init.d/iptables stop
/etc/init.d/ip6tables stop
/etc/init.d/sendmail stop 2>&1 | grep -v such
/etc/init.d/NetworkManager  stop | grep -v FAILED
echo "disable selinux...";sleep 1
sed -i s/=enable/=disabled/g /etc/selinux/config
sed -i s/=enforcing/=disabled/g /etc/selinux/config
setenforce 0 > /dev/null 2>&1

if ! uncommentfile /etc/sysctl.conf |grep  vm.overcommit_memory >>/dev/null;then
cat >> /etc/sysctl.conf << EOF
# Stop nodes OOM'ing
vm.overcommit_memory = 2
vm.overcommit_ratio = 96
EOF
fi

echo "modifying  file: /etc/security/limits.conf...";sleep 1
if ! uncommentfile /etc/security/limits.conf |grep memlock >>/dev/null;then
cat >> /etc/security/limits.conf  << EOF
*    soft    memlock    unlimited
*    hard    memlock    unlimited
*    soft    stack      unlimited
*    hard    stack      unlimited
EOF
fi
if ! uncommentfile /etc/sysconfig/pbs_mom  2>&1 |grep unlimited >> /dev/null;then
cat <<EOF >/etc/sysconfig/pbs_mom
ulimit -s unlimited
ulimit -l unlimited
EOF
fi

echo "adding  tmpwatch to /etc/crontab ...";sleep 1
mkdir -p /tmp/scratch
chmod 777 /tmp/scratch
if ! uncommentfile /etc/crontab |grep tmpwatch >>/dev/null;then
cat >> /etc/crontab << EOF
0  0  *  *  *  root tmpwatch -umc 60d /tmp/scratch
EOF
fi
/sbin/chkconfig --level 35 crond  on
/etc/init.d/crond restart


echo "Prevent kipmi0 from consuming 100% CPU"
echo 100 > /sys/module/ipmi_si/parameters/kipmid_max_busy_us 2>/dev/null
touch /etc/modprobe.d/ipmi.conf
cat <<EOF >/etc/modprobe.d/ipmi.conf
options ipmi_si kipmid_max_busy_us=100
EOF

echo "Stop bmc-watchdog to prevent node crash"
/etc/init.d/bmc-watchdog stop
chkconfig bmc-watchdog off
/etc/init.d/watchdog stop
chkconfig watchdog off
