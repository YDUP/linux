#!/bin/bash

MD5_LOG_DIR=/var/log/md5check_log
MD5_CHECK_ID=`date "+%Y%m%d-%H%M"`
MD5_LOG=$MD5_LOG_DIR/md5_record_$MD5_CHECK_ID.log
MD5_CHECK_LOG=$MD5_LOG_DIR/md5_check_$MD5_CHECK_ID.log

if [ ! -d $MD5_LOG_DIR ];then
    mkdir -p $MD5_LOG_DIR
fi

MD5_LAST_FILE=`ls -t $MD5_LOG_DIR/md5_record* 2> /dev/null | head -1`

if ! [ -z "$MD5_LAST_FILE" ];then
  md5sum -c $MD5_LAST_FILE 2>&1 | grep FAILED | grep -v OK > $MD5_CHECK_LOG
fi

/usr/sbin/tmpwatch -umc 30d -X '/var/log/md5check_log/md5_check_*.log' /var/log/md5check_log/ >> $MD5_CHECK_LOG 2>&1

find /etc -type f -print0 | xargs -0 md5sum > $MD5_LOG
find /usr -type f -print0 | xargs -0 md5sum >> $MD5_LOG
find /boot -type f -print0 | xargs -0 md5sum >> $MD5_LOG
find /bin -type f -print0 | xargs -0 md5sum >> $MD5_LOG
find /sbin -type f -print0 | xargs -0 md5sum >> $MD5_LOG
find /lib -type f -print0 | xargs -0 md5sum >> $MD5_LOG
find /lib64 -type f -print0 | xargs -0 md5sum >> $MD5_LOG
find /root -type f -print0 | xargs -0 md5sum >> $MD5_LOG
find /opt -type f -print0 | xargs -0 md5sum >> $MD5_LOG

exit 0
